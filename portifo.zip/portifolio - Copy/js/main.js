/*
// define an array for the slider
var images = [
    "assets/img/1.jpg",
    "assets/img/2.jpg",
    "assets/img/3.jpg",
    "assets/img/4.jpg"
];
var num = 0;
function next(){
    var slider = document.getElementById("slider");
    num++;
    if(num >=images.length){
        num=0;
    }
    slider.src = images[num];
}
function prev(){
    var slider = document.getElementById("slider");
    num--;
    if(num<0){
        num=images.length-1;
    }
    slider.src = images[num];
}
*/
var d = new Date(); 
var days =[
    "Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"
];
document.getElementById("home-txt").innerHTML = days[d.getDay()];
document.getElementById("home-txt").innerHTML = d.getFullYear();


/*Modal form code goes here*/

//get the modal form
var modal = document.getElementById("modalform") ;
//get the button that triggers the modal form to open
 var btn = document.getElementById("contactfrmBtn");
 //Get span element that closes the modal form
 var span = document.getElementsByClassName("close")[0];

//when the user clicks on the button, open the modal form
 btn.onclick = function(){
     modal.style.display = "block";
 }
 //when the user clicks on(X), the modal form closes
 span.onclick = function(){
     modal.style.display="none";
 }
 //when user clicks anywhere in the window the form closes
 window.onclick= function(event){
     if  (event.target ==modal){
         modal.style.display = "none";
     }
 }